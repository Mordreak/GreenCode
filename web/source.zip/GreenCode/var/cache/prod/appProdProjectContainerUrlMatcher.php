<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request;
        $requestMethod = $canonicalMethod = $context->getMethod();
        $scheme = $context->getScheme();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }


        // gc_main_homepage
        if (preg_match('#^/(?P<_theme>bright|dark)?$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'gc_main_homepage')), array (  '_controller' => 'GC\\MainBundle\\Controller\\DefaultController::indexAction',  '_theme' => 'bright',));
        }

        // gc_main_search
        if (0 === strpos($pathinfo, '/search') && preg_match('#^/search(?:/(?P<_theme>bright|dark))?$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'gc_main_search')), array (  '_controller' => 'GC\\MainBundle\\Controller\\DefaultController::searchAction',  '_theme' => 'bright',));
        }

        // gc_main_detail
        if (0 === strpos($pathinfo, '/dentist') && preg_match('#^/dentist/(?P<dentist_id>\\d+)(?:/(?P<_theme>bright|dark))?$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'gc_main_detail')), array (  '_controller' => 'GC\\MainBundle\\Controller\\DefaultController::detailAction',  '_theme' => 'bright',));
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
