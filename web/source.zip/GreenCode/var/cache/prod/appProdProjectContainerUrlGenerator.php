<?php

use Symfony\Component\Routing\RequestContext;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Psr\Log\LoggerInterface;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlGenerator extends Symfony\Component\Routing\Generator\UrlGenerator
{
    private static $declaredRoutes;

    public function __construct(RequestContext $context, LoggerInterface $logger = null)
    {
        $this->context = $context;
        $this->logger = $logger;
        if (null === self::$declaredRoutes) {
            self::$declaredRoutes = array(
        'gc_main_homepage' => array (  0 =>   array (    0 => '_theme',  ),  1 =>   array (    '_controller' => 'GC\\MainBundle\\Controller\\DefaultController::indexAction',    '_theme' => 'bright',  ),  2 =>   array (    '_theme' => 'bright|dark',  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => 'bright|dark',      3 => '_theme',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'gc_main_search' => array (  0 =>   array (    0 => '_theme',  ),  1 =>   array (    '_controller' => 'GC\\MainBundle\\Controller\\DefaultController::searchAction',    '_theme' => 'bright',  ),  2 =>   array (    '_theme' => 'bright|dark',  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => 'bright|dark',      3 => '_theme',    ),    1 =>     array (      0 => 'text',      1 => '/search',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'gc_main_detail' => array (  0 =>   array (    0 => 'dentist_id',    1 => '_theme',  ),  1 =>   array (    '_controller' => 'GC\\MainBundle\\Controller\\DefaultController::detailAction',    '_theme' => 'bright',  ),  2 =>   array (    'dentist_id' => '\\d+',    '_theme' => 'bright|dark',  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => 'bright|dark',      3 => '_theme',    ),    1 =>     array (      0 => 'variable',      1 => '/',      2 => '\\d+',      3 => 'dentist_id',    ),    2 =>     array (      0 => 'text',      1 => '/dentist',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
    );
        }
    }

    public function generate($name, $parameters = array(), $referenceType = self::ABSOLUTE_PATH)
    {
        if (!isset(self::$declaredRoutes[$name])) {
            throw new RouteNotFoundException(sprintf('Unable to generate a URL for the named route "%s" as such route does not exist.', $name));
        }

        list($variables, $defaults, $requirements, $tokens, $hostTokens, $requiredSchemes) = self::$declaredRoutes[$name];

        return $this->doGenerate($variables, $defaults, $requirements, $tokens, $parameters, $name, $referenceType, $hostTokens, $requiredSchemes);
    }
}
