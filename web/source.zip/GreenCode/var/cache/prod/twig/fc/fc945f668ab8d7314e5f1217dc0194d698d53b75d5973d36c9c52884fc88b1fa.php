<?php

/* GCMainBundle:Default:search.html.twig */
class __TwigTemplate_0d4f493ab8a466bdba9ccbde8444b572cfef8b20d8b7c286fbf8521ab710ff83 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "GCMainBundle:Default:search.html.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "    ";
        $this->loadTemplate("result.html.twig", "GCMainBundle:Default:search.html.twig", 3)->display($context);
    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        echo "Search result · ";
        $this->displayParentBlock("title", $context, $blocks);
    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        // line 7
        echo "    <div id=\"search-wrapper\">
        <div class=\"container search-box\">
            <p class=\"fs-20\">Advanced filters</p>
            <hr />
            <form class=\"advanced-search\" action='";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("gc_main_search", array("_theme" => twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "_theme"), "method"))), "html", null, true);
        echo "'>
                <div class=\"dispo\">
                    <span class=\"fs-14\">
                         Availabilities:
                    </span>
                    <div>
                        <input id=\"cb-1\" class=\"cb\" name=\"days[]\" type=\"checkbox\" ";
        // line 17
        if (twig_in_filter("mon", twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "days"), "method"))) {
            echo "checked";
        }
        echo " value=\"mon\">
                        <label for=\"cb-1\" class=\"cb-label\">Monday</label>
                    </div>
                    <div>
                        <input id=\"cb-2\" class=\"cb\" name=\"days[]\" type=\"checkbox\" ";
        // line 21
        if (twig_in_filter("tue", twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "days"), "method"))) {
            echo "checked";
        }
        echo " value=\"tue\">
                        <label for=\"cb-2\" class=\"cb-label\">Tuesday</label>
                    </div>
                    <div>
                        <input id=\"cb-3\" class=\"cb\" name=\"days[]\" type=\"checkbox\" ";
        // line 25
        if (twig_in_filter("wed", twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "days"), "method"))) {
            echo "checked";
        }
        echo " value=\"wed\">
                        <label for=\"cb-3\" class=\"cb-label\">Wednesday</label>
                    </div>
                    <div>
                        <input id=\"cb-4\" class=\"cb\" name=\"days[]\" type=\"checkbox\" ";
        // line 29
        if (twig_in_filter("thu", twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "days"), "method"))) {
            echo "checked";
        }
        echo " value=\"thu\">
                        <label for=\"cb-4\" class=\"cb-label\">Thursday</label>
                    </div>
                    <div>
                        <input id=\"cb-5\" class=\"cb\" name=\"days[]\" type=\"checkbox\" ";
        // line 33
        if (twig_in_filter("fri", twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "days"), "method"))) {
            echo "checked";
        }
        echo " value=\"fri\">
                        <label for=\"cb-5\" class=\"cb-label\">Friday</label>
                    </div>
                </div>
                <hr/>
                <div class=\"filters-wrapper\">
                    <div class=\"specialization\">
                        <label class=\"fs-14\" for=\"spec\">
                            Specialization:
                        </label>
                        <div class=\"select\">
                            <select id=\"spec\" name=\"spec\">
                                <option value=\"\">All specializations</option>
                                <option ";
        // line 46
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "spec"), "method") == "dph")) {
            echo "selected";
        }
        echo " value=\"dph\">Dental Public Health</option>
                                <option ";
        // line 47
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "spec"), "method") == "end")) {
            echo "selected";
        }
        echo " value=\"end\">Endodontics</option>
                                <option ";
        // line 48
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "spec"), "method") == "omp")) {
            echo "selected";
        }
        echo " value=\"omp\">Oral and Maxillofacial Pathology</option>
                                <option ";
        // line 49
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "spec"), "method") == "omr")) {
            echo "selected";
        }
        echo " value=\"omr\">Oral and Maxillofacial Radiology</option>
                                <option ";
        // line 50
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "spec"), "method") == "oms")) {
            echo "selected";
        }
        echo " value=\"oms\">Oral and Maxillofacial Surgery</option>
                                <option ";
        // line 51
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "spec"), "method") == "odo")) {
            echo "selected";
        }
        echo " value=\"odo\">Orthodontics and Dentofacial Orthopedics</option>
                                <option ";
        // line 52
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "spec"), "method") == "pd")) {
            echo "selected";
        }
        echo " value=\"pd\">Pediatric Dentistry</option>
                                <option ";
        // line 53
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "spec"), "method") == "per")) {
            echo "selected";
        }
        echo " value=\"per\">Periodontics</option>
                                <option ";
        // line 54
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "spec"), "method") == "pro")) {
            echo "selected";
        }
        echo " value=\"pro\">Prosthodontics</option>
                            </select>
                        </div>
                    </div>
                    <div>
                        <label class=\"fs-14\" for=\"q\">
                            Search:
                        </label>
                        <div class=\"search\">
                            <input id=\"q\" maxlength=\"255\" placeholder=\"Name, Firstname Or Address...\" type=\"text\" name=\"q\" value=\"";
        // line 63
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "q"), "method"), "html", null, true);
        echo "\">
                        </div>
                    </div>
                </div>
                <button class=\"fs-14 advanced-submit\" type=\"submit\">Search &raquo;</button>
            </form>
        </div>
        <div class=\"container search-box results\">
            ";
        // line 71
        if (($context["query"] ?? null)) {
            // line 72
            echo "                <p>Search results for « ";
            echo twig_escape_filter($this->env, ($context["query"] ?? null), "html", null, true);
            echo " »</p>
            ";
        } else {
            // line 74
            echo "                <p>All dentists</p>
            ";
        }
        // line 76
        echo "            ";
        if (($context["resultsCount"] ?? null)) {
            // line 77
            echo "                <p>";
            echo twig_escape_filter($this->env, ($context["resultsCount"] ?? null), "html", null, true);
            echo " result";
            if ((($context["resultsCount"] ?? null) > 1)) {
                echo "s";
            }
            echo " found</p>
            ";
        } else {
            // line 79
            echo "                <p>No results found so far.</p>
            ";
        }
        // line 81
        echo "        </div>
        ";
        // line 82
        if (($context["results"] ?? null)) {
            // line 83
            echo "            <div class=\"container search-results\">
                ";
            // line 84
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["results"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["dentist"]) {
                // line 85
                echo "                    <a class=\"search-result-item\" href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("gc_main_detail", array("dentist_id" => twig_get_attribute($this->env, $this->getSourceContext(), $context["dentist"], "id", array()), "_theme" => twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "_theme"), "method"))), "html", null, true);
                echo "\">
                        <div class=\"detail\">
                            <ul>
                                <li class=\"name\">";
                // line 88
                if (twig_get_attribute($this->env, $this->getSourceContext(), $context["dentist"], "gender", array())) {
                    echo "Mr ";
                } else {
                    echo "Mrs ";
                }
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["dentist"], "firstname", array()), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["dentist"], "lastname", array()), "html", null, true);
                echo "</li>
                                ";
                // line 89
                if ((twig_length_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["dentist"], "specialty", array())) > 0)) {
                    // line 90
                    echo "                                    <li class=\"specialty\">";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["dentist"], "specialty", array()), "html", null, true);
                    echo "</li>
                                ";
                }
                // line 92
                echo "                                <li class=\"address\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["dentist"], "address", array()), "html", null, true);
                echo ",</li>
                                <li class=\"city\">";
                // line 93
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["dentist"], "city", array()), "html", null, true);
                echo "</li>
                                <li class=\"phone\">Tel: ";
                // line 94
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["dentist"], "phone", array()), "html", null, true);
                echo "</li>
                            </ul>
                        </div>
                        <div class=\"right\">
                            <div class=\"photo\">
                                ";
                // line 99
                if ((twig_length_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["dentist"], "image", array())) > 0)) {
                    // line 100
                    echo "                                    <img src=\"";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["dentist"], "image", array()), "html", null, true);
                    echo "\"
                                         alt=\"";
                    // line 101
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["dentist"], "firstname", array()), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["dentist"], "lastname", array()), "html", null, true);
                    echo "'s photo\"/>
                                ";
                }
                // line 103
                echo "                            </div>
                            <div class=\"visited\">";
                // line 104
                if (twig_get_attribute($this->env, $this->getSourceContext(), ($context["dentists"] ?? null), twig_get_attribute($this->env, $this->getSourceContext(), $context["dentist"], "id", array()), array(), "array", true, true)) {
                    echo "Visited";
                }
                echo "</div>
                        </div>
                    </a>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['dentist'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 108
            echo "            </div>
            ";
            // line 109
            if ((($context["maxPage"] ?? null) > 1)) {
                // line 110
                echo "                <div class=\"container pagination\">
                    <div class=\"pages\">
                        ";
                // line 112
                if ((($context["page"] ?? null) > 1)) {
                    // line 113
                    echo "                            ";
                    if (twig_in_filter("p=", twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "uri", array()))) {
                        // line 114
                        echo "                                <a href=\"";
                        echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "uri", array()), array(("p=" . ($context["page"] ?? null)) => "p=1")), "html", null, true);
                        echo "\">&laquo;</a>
                            ";
                    } else {
                        // line 116
                        echo "                                <a href=\"";
                        echo twig_escape_filter($this->env, (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "uri", array()) . "&p=1"), "html", null, true);
                        echo "\">&laquo;</a>
                            ";
                    }
                    // line 118
                    echo "                        ";
                }
                // line 119
                echo "                        ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(range( -2, 2));
                foreach ($context['_seq'] as $context["_key"] => $context["n"]) {
                    // line 120
                    echo "                            ";
                    if ((((($context["page"] ?? null) + $context["n"]) > 0) && ((($context["page"] ?? null) + $context["n"]) <= ($context["maxPage"] ?? null)))) {
                        // line 121
                        echo "                                ";
                        if (((($context["page"] ?? null) + $context["n"]) == ($context["page"] ?? null))) {
                            // line 122
                            echo "                                    <a href=\"#\" class=\"active disabled\">";
                            echo twig_escape_filter($this->env, (($context["page"] ?? null) + $context["n"]), "html", null, true);
                            echo "</a>
                                ";
                        } else {
                            // line 124
                            echo "                                    ";
                            if (twig_in_filter("p=", twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "uri", array()))) {
                                // line 125
                                echo "                                        <a href=\"";
                                echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "uri", array()), array(("p=" . ($context["page"] ?? null)) => ("p=" . (($context["page"] ?? null) + $context["n"])))), "html", null, true);
                                echo "\">";
                                echo twig_escape_filter($this->env, (($context["page"] ?? null) + $context["n"]), "html", null, true);
                                echo "</a>
                                    ";
                            } else {
                                // line 127
                                echo "                                        <a href=\"";
                                echo twig_escape_filter($this->env, (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "uri", array()) . ("&p=" . (($context["page"] ?? null) + $context["n"]))), "html", null, true);
                                echo "\">";
                                echo twig_escape_filter($this->env, (($context["page"] ?? null) + $context["n"]), "html", null, true);
                                echo "</a>
                                    ";
                            }
                            // line 129
                            echo "                                ";
                        }
                        // line 130
                        echo "                            ";
                    }
                    // line 131
                    echo "                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['n'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 132
                echo "                        ";
                if ((($context["page"] ?? null) < ($context["maxPage"] ?? null))) {
                    // line 133
                    echo "                            ";
                    if (twig_in_filter("p=", twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "uri", array()))) {
                        // line 134
                        echo "                                <a href=\"";
                        echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "uri", array()), array(("p=" . ($context["page"] ?? null)) => ("p=" . ($context["maxPage"] ?? null)))), "html", null, true);
                        echo "\">&raquo;</a>
                            ";
                    } else {
                        // line 136
                        echo "                                <a href=\"";
                        echo twig_escape_filter($this->env, (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "uri", array()) . ("&p=" . ($context["maxPage"] ?? null))), "html", null, true);
                        echo "\">&raquo;</a>
                            ";
                    }
                    // line 138
                    echo "                        ";
                }
                // line 139
                echo "                    </div>
                </div>
            ";
            }
            // line 142
            echo "        ";
        }
        // line 143
        echo "    </div>
";
    }

    public function getTemplateName()
    {
        return "GCMainBundle:Default:search.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  409 => 143,  406 => 142,  401 => 139,  398 => 138,  392 => 136,  386 => 134,  383 => 133,  380 => 132,  374 => 131,  371 => 130,  368 => 129,  360 => 127,  352 => 125,  349 => 124,  343 => 122,  340 => 121,  337 => 120,  332 => 119,  329 => 118,  323 => 116,  317 => 114,  314 => 113,  312 => 112,  308 => 110,  306 => 109,  303 => 108,  291 => 104,  288 => 103,  281 => 101,  276 => 100,  274 => 99,  266 => 94,  262 => 93,  257 => 92,  251 => 90,  249 => 89,  238 => 88,  231 => 85,  227 => 84,  224 => 83,  222 => 82,  219 => 81,  215 => 79,  205 => 77,  202 => 76,  198 => 74,  192 => 72,  190 => 71,  179 => 63,  165 => 54,  159 => 53,  153 => 52,  147 => 51,  141 => 50,  135 => 49,  129 => 48,  123 => 47,  117 => 46,  99 => 33,  90 => 29,  81 => 25,  72 => 21,  63 => 17,  54 => 11,  48 => 7,  45 => 6,  38 => 5,  33 => 3,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "GCMainBundle:Default:search.html.twig", "/workspace/GreenCode/src/GC/MainBundle/Resources/views/Default/search.html.twig");
    }
}
