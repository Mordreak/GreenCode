<?php

/* result.html.twig */
class __TwigTemplate_f37497352f08d7bb2a7b1ea78dc5ce0762b5de8e11a92b07ce00cf0fcab9c534 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<style>
    *{margin:0;padding:0}.container{width:100%;padding:0 10%;margin:auto;box-sizing:border-box}.title{font-family:Georgia;font-size:32px;cursor:pointer}.fa-home{font-size:22px}.search-box{width:80%;min-width:280px;max-width:750px;margin:40px auto 0 auto;position:relative;transition:opacity 0.4s linear,visibility 0.4s linear 0s;border-radius:6px;border:none;outline:0;font-size:16px;font-family:Arial,Helvetica,sans-serif;text-align:center;padding:12px}.search-box.results{width:250px;min-width:0}.search-results{display:flex;flex-wrap:wrap;justify-content:space-between;padding-bottom:50px}.search-results .search-result-item{width:45%;margin:40px 0 0 0;box-shadow:none;border-radius:6px;text-decoration:none;outline:0;font-size:16px;font-family:Arial,Helvetica,sans-serif;box-sizing:border-box;display:flex;flex-direction:row;justify-content:space-around;padding:12px;border:1px solid white}@media all and (max-width:1000px){.search-results .search-result-item{width:100%}}.search-results .search-result-item:hover{cursor:pointer;box-shadow:0 2px 14px rgba(51,51,51,.2);transition:border 400ms ease-out,box-shadow 400ms ease-out}.search-results .search-result-item .detail{width:60%;padding:12px}.search-results .search-result-item .detail ul{list-style:none}.search-results .search-result-item .detail ul .name{font-size:20px;font-weight:600}.search-results .search-result-item .detail ul .address{margin-top:10px;font-size:14px}.search-results .search-result-item .detail ul .city{margin-top:3px;font-size:15px;text-transform:uppercase}.search-results .search-result-item .detail ul .phone{font-size:14px;margin-top:10px}.search-results .search-result-item .right{width:30%;padding:12px;text-align:right;display:flex;flex-direction:column;justify-content:space-between;align-items:flex-end}#search-wrapper{width:100%;position:relative;margin:0;padding:50px 0 0 0;display:inline-block;height:auto}.cb{opacity:0;position:absolute}.cb,.cb-label{display:inline-block;vertical-align:middle;margin:5px;cursor:pointer}.cb-label{position:relative}.cb + .cb-label:before{content:'';background:#fff;border:1px solid #ddd;display:inline-block;vertical-align:middle;width:10px;height:10px;padding:2px;margin-right:5px;text-align:center}.cb:checked + .cb-label:before{box-shadow:inset 0 0 0 2px #fff}.cb-label{font-size:14px}.cb:focus + .cb-label,.radio-custom:focus + .radio-custom-label{outline:1px solid #ddd}h1{text-align:center}select{-webkit-appearance:none;-moz-appearance:none;-ms-appearance:none;appearance:none;outline:0;box-shadow:none;border:0!important;background-image:none}.select{position:relative;display:block;height:30px;overflow:hidden;border-radius:3px;margin-top:5px;color:white!important}select{width:100%;height:100%;margin:0;padding:0 0 0 .5em;color:#fff;cursor:pointer}select::-ms-expand{display:none}.select::after{content:'\\25BC';position:absolute;top:7px;right:0;bottom:0;padding:0 1em;pointer-events:none}.select:hover::after{color:white}.select::after{-webkit-transition:.25s all ease;-o-transition:.25s all ease;transition:.25s all ease}.dispo div{display:inline-block}.container.search-box hr{margin:10px}.advanced-submit{color:#fff;width:245px;background-color:#bbb;border:none;text-align:center;cursor:pointer;border-radius:3px;padding:10px 30px}.filters-wrapper{display:flex;justify-content:space-around;margin-bottom:15px}.filters-wrapper>div{width:40%;min-width:244px;padding:0}.specialization .select{height:32px}.specialization .select select{height:32px;padding:0 10px;line-height:32px}.opening{width:40%}.search input{height:30px;width:220px;border-radius:6px;border:1px solid darkgrey}.search input,.search input:focus{display:block;box-shadow:none;background-color:none;outline:0;font-size:14px;font-family:Arial,sans-serif;color:#bbb;padding:0 12px}.search{height:30px;margin-top:5px}.pagination{font-family:Arial,Helvetica,sans-serif;padding-bottom:50px;display:flex;flex-direction:column;align-items:center}.pagination .pages{display:flex;justify-content:center;border-radius:6px;text-decoration:none;border:none;background-color:#fff;font-family:Arial,Helvetica,sans-serif}.pagination .pages:hover{box-shadow:2px 2px 2px gray}.pagination .pages a{color:#555;float:left;padding:8px 16px;text-decoration:none}.pagination .pages a.disabled{cursor:default}.pagination .pages a:first-of-type{border-radius:6px 0 0 6px}.pagination .pages a:last-of-type{border-radius:0 6px 6px 0}.pagination .pages a.active{color:white}.pagination .pages a:hover:not(.disabled){background-color:#ddd}  .search-box {  ";
        // line 2
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "_theme"), "method") == "bright")) {
            echo "background-color: #fff; color: #555;  ";
        } else {
            echo " background-color: #555;  color: #fff;  ";
        }
        echo " }  .search-results .search-result-item { ";
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "_theme"), "method") == "bright")) {
            echo " background-color: #fff;  color: #555; ";
        } else {
            echo "  background-color: #555;   color: #fff; ";
        }
        echo " }     .search-results .search-result-item:hover {  ";
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "_theme"), "method") == "bright")) {
            echo " border: 1px solid green; ";
        } else {
            echo " border: 1px solid black; ";
        }
        echo " } .search-results .search-result-item .detail ul .name { ";
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "_theme"), "method") == "bright")) {
            echo " color: #333;";
        } else {
            echo " color: #fff;";
        }
        echo " } .cb:checked + .cb-label:before {  ";
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "_theme"), "method") == "bright")) {
            echo " background: #62bb49;";
        } else {
            echo " background: black;";
        }
        echo " } select {  ";
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "_theme"), "method") == "bright")) {
            echo "  background: #98d17a; ";
        } else {
            echo "  background: black; ";
        }
        echo " } .select { ";
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "_theme"), "method") == "bright")) {
            echo "   background: #98d17a;   ";
        } else {
            echo "   background: black;   ";
        }
        echo "  } .select::after { ";
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "_theme"), "method") == "bright")) {
            echo "  background: #98d17a;  ";
        } else {
            echo "   background: black; ";
        }
        echo "  } .advanced-submit:hover { ";
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "_theme"), "method") == "bright")) {
            echo "  background: #98d17a;  ";
        } else {
            echo "  background: black;   ";
        }
        echo "   }.pagination .pages a.active {  ";
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "request", array()), "get", array(0 => "_theme"), "method") == "bright")) {
            echo "  background-color: #4CAF50;  ";
        } else {
            echo "  background-color: rgb(50, 50, 50);  ";
        }
        echo "  }
</style>";
    }

    public function getTemplateName()
    {
        return "result.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 2,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "result.html.twig", "/workspace/GreenCode/app/Resources/views/result.html.twig");
    }
}
